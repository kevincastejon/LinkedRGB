namespace LinkedLamp.Models;

public class ProvisioningContext
{
    public string Ssid { get; set; } = "";
    public string Password { get; set; } = "";
    public string GroupName { get; set; } = "";
}
